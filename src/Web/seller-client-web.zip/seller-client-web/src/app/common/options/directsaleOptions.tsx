﻿export const directsaleOptions = [
    { key: "ds", text: "DirectSale", value: "directsale" },
    { key: "co", text: "Closed", value: "closed" }
];
